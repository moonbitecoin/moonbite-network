MoonBite Core Wallet (Linux x86-64)
===================================

Version: v0.21.5.5  ·  Ticker: MBITE  ·  Addresses: moon1... (mainnet)

WHAT'S INSIDE
  moonbite-qt      Desktop GUI wallet (send/receive/mine, full node)
  moonbited        Headless full-node daemon (server/RPC)
  moonbite-cli     Command-line control for moonbited
  moonbite.conf.example   Sample config (rename to moonbite.conf)

QUICK START (GUI wallet)
  1. tar -xzf moonbite-wallet-linux-x86_64.tar.gz && cd moonbite-wallet
  2. chmod +x moonbite-qt moonbited moonbite-cli
  3. ./moonbite-qt
  The wallet creates its data directory at ~/.moonbite on first run.

QUICK START (headless node)
  1. mkdir -p ~/.moonbite
  2. cp moonbite.conf.example ~/.moonbite/moonbite.conf   # then edit rpcuser/rpcpassword
  3. ./moonbited -daemon
  4. ./moonbite-cli getblockchaininfo

CONNECT TO THE NETWORK
  The wallet syncs from the live seed node automatically once seeds are
  baked into the client. To connect manually, add to moonbite.conf:
    addnode=<seed-node-host>:9444
  or run:  ./moonbite-cli addnode <seed-node-host>:9444 onetry

DEPENDENCIES (Ubuntu 22.04 / Debian 12)
  sudo apt install libboost-filesystem1.74.0 libboost-thread1.74.0 \
    libdb5.3++ libevent-2.1-7 libevent-pthreads-2.1-7 libfmt8 \
    libsqlite3-0 libssl3
  (moonbite-qt additionally needs the Qt5 runtime: libqt5gui5 libqt5network5)

VERIFY YOUR DOWNLOAD
  sha256sum -c SHA256SUMS.txt

NOTE
  These are Linux x86-64 binaries. Windows/macOS builds are not included in
  this bundle. On Windows use WSL2 (Ubuntu 22.04) to run them, or use the
  browser / one-click Python miner from the Download page instead.
